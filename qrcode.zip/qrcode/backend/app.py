import sqlite3
import uuid
import qrcode
import base64
from io import BytesIO
from datetime import datetime
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import joblib
import pandas as pd
import shap
import numpy as np
import lightgbm
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount the static directory
app.mount("/static", StaticFiles(directory="static"), name="static")
# Load the saved model
model_path = 'diabetes_lgb_model.joblib'
lgb_model = joblib.load(model_path)
clinical_explanations = {
    "Age": {
        "high": "Advanced age is a known risk factor for diabetes and other metabolic disorders.",
        "normal": "Age is within a normal range.",
        "suggestion": "Regular health checkups are recommended."
    },
    "Gender": {
        "high": "Certain diabetes risk factors may vary by gender.",
        "normal": "No significant impact on diabetes risk.",
        "suggestion": "Monitor based on individual risk factors."
    },
    "Polyuria": {
        "high": "Frequent urination can be a sign of high blood sugar levels.",
        "normal": "No excessive urination reported.",
        "suggestion": "Monitor fluid intake and check blood sugar levels."
    },
    "Polydipsia": {
        "high": "Excessive thirst is a common symptom of diabetes.",
        "normal": "No unusual thirst levels reported.",
        "suggestion": "Consider checking blood glucose levels if persistent."
    },
    "sudden weight loss": {
        "high": "Unexplained weight loss may indicate uncontrolled diabetes.",
        "normal": "Weight is stable.",
        "suggestion": "Consult a doctor for potential metabolic concerns."
    },
    "weakness": {
        "high": "Weakness can be a symptom of high or low blood sugar.",
        "normal": "No unusual fatigue or weakness reported.",
        "suggestion": "Monitor energy levels and consider a balanced diet."
    },
    "Polyphagia": {
        "high": "Excessive hunger may indicate blood sugar fluctuations.",
        "normal": "Appetite is within a normal range.",
        "suggestion": "Monitor food intake and check glucose levels."
    },
    "Genital thrush": {
        "high": "Frequent fungal infections can be associated with diabetes.",
        "normal": "No infections reported.",
        "suggestion": "Maintain good hygiene and monitor blood sugar levels."
    },
    "visual blurring": {
        "high": "Blurry vision can result from fluctuating blood sugar levels.",
        "normal": "No visual disturbances reported.",
        "suggestion": "Consider an eye examination and blood sugar test."
    },
    "Itching": {
        "high": "Persistent itching can be linked to diabetes or skin infections.",
        "normal": "No unusual itching reported.",
        "suggestion": "Keep skin hydrated and monitor for infections."
    },
    "Irritability": {
        "high": "Mood swings and irritability can be related to blood sugar fluctuations.",
        "normal": "Mood is stable.",
        "suggestion": "Maintain stable blood sugar levels through diet."
    },
    "delayed healing": {
        "high": "Slow healing of wounds is a common sign of diabetes.",
        "normal": "Normal healing observed.",
        "suggestion": "Monitor for infections and maintain good wound care."
    },
    "partial paresis": {
        "high": "Weakness or partial paralysis can be a neurological complication.",
        "normal": "No muscle weakness reported.",
        "suggestion": "Consider neurological evaluation if persistent."
    },
    "muscle stiffness": {
        "high": "Muscle stiffness can be associated with metabolic imbalances.",
        "normal": "No unusual stiffness reported.",
        "suggestion": "Regular physical activity can help maintain mobility."
    },
    "Alopecia": {
        "high": "Hair loss may be associated with endocrine disorders.",
        "normal": "No significant hair loss reported.",
        "suggestion": "Monitor thyroid and metabolic health."
    },
    "Obesity": {
        "high": "Obesity is a major risk factor for diabetes and metabolic disorders.",
        "normal": "Weight is within a healthy range.",
        "suggestion": "Maintain a balanced diet and regular exercise routine."
    },
    "symptom_index": {
        "high": "High symptom index indicates a strong likelihood of diabetes.",
        "normal": "Symptom index is within a safe range.",
        "suggestion": "Consult a healthcare provider for further assessment."
    },
    "sudden_weight_loss": {
        "high": "Unexplained weight loss may indicate uncontrolled diabetes.",
        "normal": "Weight is stable.",
        "suggestion": "Consult a doctor for potential metabolic concerns."
    }
}

# Pydantic models
class UserCreate(BaseModel):
    aadhaar_number: str
    name: str
    date_of_birth: str
    gender: str
    location: str

class ClinicalDataCreate(BaseModel):
    aadhaar_number: str
    polyuria: bool
    polydipsia: bool
    sudden_weight_loss: bool
    weakness: bool
    polyphagia: bool
    genital_thrush: bool
    visual_blurring: bool
    itching: bool
    irritability: bool
    delayed_healing: bool
    partial_paresis: bool
    muscle_stiffness: bool
    alopecia: bool
    obesity: bool
    class_: str  # Renamed to avoid Python keyword conflict (Positive/Negative)

class UserResponse(BaseModel):
    aadhaar_number: str
    name: str
    date_of_birth: str
    gender: str
    location: str
    age: int
    unique_code: str
    qr_code: str
    clinical_data: dict | None = None  # Optional clinical data

# Database setup
def init_db():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    
    # Primary table: users
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            aadhaar_number TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            date_of_birth TEXT NOT NULL,
            gender TEXT NOT NULL,
            location TEXT NOT NULL,
            age INTEGER NOT NULL,
            unique_code TEXT NOT NULL UNIQUE,  -- Ensure unique_code is unique
            qr_code TEXT NOT NULL
        )
    ''')
    
    # Secondary table: clinical_data
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clinical_data (
            aadhaar_number TEXT PRIMARY KEY,
            polyuria INTEGER NOT NULL,
            polydipsia INTEGER NOT NULL,
            sudden_weight_loss INTEGER NOT NULL,
            weakness INTEGER NOT NULL,
            polyphagia INTEGER NOT NULL,
            genital_thrush INTEGER NOT NULL,
            visual_blurring INTEGER NOT NULL,
            itching INTEGER NOT NULL,
            irritability INTEGER NOT NULL,
            delayed_healing INTEGER NOT NULL,
            partial_paresis INTEGER NOT NULL,
            muscle_stiffness INTEGER NOT NULL,
            alopecia INTEGER NOT NULL,
            obesity INTEGER NOT NULL,
            class TEXT NOT NULL,
            FOREIGN KEY (aadhaar_number) REFERENCES users(aadhaar_number) ON DELETE CASCADE
        )
    ''')
    
    conn.commit()
    conn.close()

# Utility functions
def generate_unique_code():
    return str(uuid.uuid4())

def generate_qr_code(unique_code: str) -> str:
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(unique_code)
    qr.make(fit=True)
    img = qr.make_image(fill="black", back_color="white")
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")

def calculate_age(date_of_birth: str) -> int:
    try:
        dob = datetime.strptime(date_of_birth, "%Y-%m-%d")
        today = datetime.now()
        age = today.year - dob.year
        if today.month < dob.month or (today.month == dob.month and today.day < dob.day):
            age -= 1
        return age
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid date_of_birth format. Use YYYY-MM-DD.")

# Database logic
def check_user_exists(aadhaar_number: str) -> dict:
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE aadhaar_number = ?", (aadhaar_number,))
    user_result = cursor.fetchone()
    
    # Fetch clinical data if it exists
    cursor.execute("SELECT * FROM clinical_data WHERE aadhaar_number = ?", (aadhaar_number,))
    clinical_result = cursor.fetchone()
    
    conn.close()
    
    if user_result:
        user_data = {
            "aadhaar_number": user_result[0],
            "name": user_result[1],
            "date_of_birth": user_result[2],
            "gender": user_result[3],
            "location": user_result[4],
            "age": user_result[5],
            "unique_code": user_result[6],
            "qr_code": user_result[7]
        }
        if clinical_result:
            user_data["clinical_data"] = {
                "polyuria": bool(clinical_result[1]),
                "polydipsia": bool(clinical_result[2]),
                "sudden_weight_loss": bool(clinical_result[3]),
                "weakness": bool(clinical_result[4]),
                "polyphagia": bool(clinical_result[5]),
                "genital_thrush": bool(clinical_result[6]),
                "visual_blurring": bool(clinical_result[7]),
                "itching": bool(clinical_result[8]),
                "irritability": bool(clinical_result[9]),
                "delayed_healing": bool(clinical_result[10]),
                "partial_paresis": bool(clinical_result[11]),
                "muscle_stiffness": bool(clinical_result[12]),
                "alopecia": bool(clinical_result[13]),
                "obesity": bool(clinical_result[14]),
                "class": clinical_result[15]
            }
        return user_data
    return None

def check_user_by_unique_code(unique_code: str) -> dict:
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE unique_code = ?", (unique_code,))
    user_result = cursor.fetchone()
    
    if user_result:
        aadhaar_number = user_result[0]
        cursor.execute("SELECT * FROM clinical_data WHERE aadhaar_number = ?", (aadhaar_number,))
        clinical_result = cursor.fetchone()
        
        conn.close()
        
        user_data = {
            "aadhaar_number": user_result[0],
            "name": user_result[1],
            "date_of_birth": user_result[2],
            "gender": user_result[3],
            "location": user_result[4],
            "age": user_result[5],
            "unique_code": user_result[6],
            "qr_code": user_result[7]
        }
        if clinical_result:
            user_data["clinical_data"] = {
                "polyuria": bool(clinical_result[1]),
                "polydipsia": bool(clinical_result[2]),
                "sudden_weight_loss": bool(clinical_result[3]),
                "weakness": bool(clinical_result[4]),
                "polyphagia": bool(clinical_result[5]),
                "genital_thrush": bool(clinical_result[6]),
                "visual_blurring": bool(clinical_result[7]),
                "itching": bool(clinical_result[8]),
                "irritability": bool(clinical_result[9]),
                "delayed_healing": bool(clinical_result[10]),
                "partial_paresis": bool(clinical_result[11]),
                "muscle_stiffness": bool(clinical_result[12]),
                "alopecia": bool(clinical_result[13]),
                "obesity": bool(clinical_result[14]),
                "class": clinical_result[15]
            }
        return user_data
    conn.close()
    return None

def add_user(user: UserCreate) -> dict:
    age = calculate_age(user.date_of_birth)
    unique_code = generate_unique_code()
    qr_code = generate_qr_code(unique_code)

    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO users (aadhaar_number, name, date_of_birth, gender, location, age, unique_code, qr_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (user.aadhaar_number, user.name, user.date_of_birth, user.gender, user.location, age, unique_code, qr_code)
    )
    conn.commit()
    conn.close()

    return {
        "aadhaar_number": user.aadhaar_number,
        "name": user.name,
        "date_of_birth": user.date_of_birth,
        "gender": user.gender,
        "location": user.location,
        "age": age,
        "unique_code": unique_code,
        "qr_code": qr_code
    }

def add_clinical_data(clinical_data: ClinicalDataCreate) -> dict:
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    
    # Check if user exists
    cursor.execute("SELECT aadhaar_number FROM users WHERE aadhaar_number = ?", (clinical_data.aadhaar_number,))
    if not cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=404, detail="User not found. Add user first.")
    
    # Insert or replace clinical data
    cursor.execute(
        """
        INSERT OR REPLACE INTO clinical_data (
            aadhaar_number, polyuria, polydipsia, sudden_weight_loss, weakness, polyphagia, 
            genital_thrush, visual_blurring, itching, irritability, delayed_healing, 
            partial_paresis, muscle_stiffness, alopecia, obesity, class
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            clinical_data.aadhaar_number,
            int(clinical_data.polyuria),
            int(clinical_data.polydipsia),
            int(clinical_data.sudden_weight_loss),
            int(clinical_data.weakness),
            int(clinical_data.polyphagia),
            int(clinical_data.genital_thrush),
            int(clinical_data.visual_blurring),
            int(clinical_data.itching),
            int(clinical_data.irritability),
            int(clinical_data.delayed_healing),
            int(clinical_data.partial_paresis),
            int(clinical_data.muscle_stiffness),
            int(clinical_data.alopecia),
            int(clinical_data.obesity),
            clinical_data.class_
        )
    )
    conn.commit()
    conn.close()
    
    return clinical_data.dict()
def assign_risk(probability):
    if probability >= 0.7:
        return "High"
    elif probability >= 0.4:
        return "Moderate"
    else:
        return "Low"
def generate_explanation(patient_data, probability, top_features):
    risk_level = assign_risk(probability)
    explanation = {"risk_level": risk_level, "details": [], "suggestions": []}
    
    # Focus on top features
    for feature in top_features:
        value = patient_data[feature]
        status = 'high' if (feature == 'Age' and value > 50) or (feature != 'Age' and value == 1) else 'normal'
        explanation['details'].append(f"{feature}: {clinical_explanations[feature][status]}")
        explanation['suggestions'].append(clinical_explanations[feature]['suggestion'])
    if status == 'high':
        explanation['suggestions'].append(clinical_explanations[feature]['suggestion'])
    
    # Summary
    explanation['summary'] = f"Your diabetes risk is {risk_level.lower()} ({probability:.0%}). "
    if risk_level == 'High':
        explanation['summary'] += "Key factors: " + ", ".join([f for f in top_features if patient_data[f] == 1 or (f == 'Age' and patient_data[f] > 50)]) + "."
    elif risk_level == 'Moderate':
        explanation['summary'] += "Monitor your symptoms closely."
    else:
        explanation['summary'] += "Keep up your healthy habits!"

    return explanation
# FastAPI endpoints
@app.on_event("startup")
async def startup_event():
    init_db()

@app.post("/add_or_get_user", response_model=UserResponse)
async def add_or_get_user(user: UserCreate):
    existing_user = check_user_exists(user.aadhaar_number)
    if existing_user:
        return existing_user
    else:
        new_user = add_user(user)
        return new_user

@app.post("/add_clinical_data")
async def add_clinical_data_endpoint(clinical_data: ClinicalDataCreate):
    result = add_clinical_data(clinical_data)
    return {"message": "Clinical data added successfully", "data": result}

@app.get("/get_user/{aadhaar_number}", response_model=UserResponse)
async def get_user(aadhaar_number: str):
    existing_user = check_user_exists(aadhaar_number)
    if existing_user:
        return existing_user
    raise HTTPException(status_code=404, detail="User not found")

@app.get("/get_user_by_unique_code/{unique_code}", response_model=UserResponse)
async def get_user_by_unique_code(unique_code: str):
    existing_user = check_user_by_unique_code(unique_code)
    if existing_user:
        return existing_user
    raise HTTPException(status_code=404, detail="User not found for this QR code")

@app.get("/")
async def serve_home():
    return FileResponse("static/generate.html")

@app.get("/scan")
async def serve_scan():
    return FileResponse("static/scan.html")
@app.post("/predict")
async def predict(data: dict):
    df = pd.DataFrame([data])

    # Preprocessing
    df['Gender'] = df['Gender'].map({'Male': 1, 'Female': 0})
    for col in df.columns[2:]:  # Yes/No columns
        df[col] = df[col].map({'Yes': 1, 'No': 0})
    df['symptom_index'] = df[['Polyuria', 'Polydipsia', 'Polyphagia']].sum(axis=1)
    df['risk_factor'] = df.apply(lambda row: sum([row['Polyuria'], row['Polydipsia'], row['Obesity'], row['Age'] > 50]), axis=1)

    # Prediction
    probability = lgb_model.predict_proba(df)[0, 1]

    # Compute SHAP values
    explainer = shap.TreeExplainer(lgb_model)
    shap_values = explainer.shap_values(df)
    shap_values_positive = shap_values[1] if isinstance(shap_values, list) else shap_values
    top_features = np.argsort(np.abs(shap_values_positive[0]))[::-1][:5]
    feature_names = df.columns[top_features]

    # Generate explanation
    explanation = generate_explanation(df.iloc[0], probability, feature_names)
    return explanation


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)